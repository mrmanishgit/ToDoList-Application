# TODOList
A simple yet powerful to-do list app

<a href='https://play.google.com/store/apps/details?id=com.skapps.android.exercisescourse&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png' height="40%" width="40%"/></a>

Features:
1. Add new tasks and set priorities to tasks.
2. Progress bar to keep you updated about your progress. 
3. Swipe to delete task.
4. Drag to change position.
5. Update tasks.


<h3>Screen Shots</h3>

<img src="/screenshots/screenshot1.png" height="50%" width="50%" >
<img src="/screenshots/screenshot2.png" height="50%" width="50%" >
<img src="/screenshots/screenshot3.png" height="50%" width="50%" >
<img src="/screenshots/screenshot4.png" height="50%" width="50%" >

